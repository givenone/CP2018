public class LLStringTest
{
	public static void main(String[] ar)
	{
		LLString llstr = new LLString("Programming");
		System.out.println(llstr.charAt(2));
		System.out.println(llstr.length());
		System.out.println(llstr.toString());
	}
}

