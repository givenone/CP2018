public class LLString
{
	/* Add internal field variables here. */

	/* Constructor. */
	public LLString(String str)
	{

	}

	/* Add methods here. */
	/* For example. */
	public char charAt(int index)
	{

	}
}
