public class CBTreeTest
{
	public static void main(String[] ar)
	{
		CBTree cbt = new CBTree("0101011", "TCS");
		System.out.println(CBTree.postOrderTraversal());
		System.out.println(CBTree.inOrderTraversal());
		System.out.println(CBTree.postOrderStructure());
		System.out.println(CBTree.inOrderStructure());
	}
}

