public class CBTree {
	public CBNode root;

	/* Helper method. */
	public CBNode getRoot()
	{
		return root;
	}
}
